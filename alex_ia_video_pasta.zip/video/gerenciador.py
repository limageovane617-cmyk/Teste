# ============================================================
# 🎬 ALEX IA ULTRA — GERENCIADOR DE MOTORES DE VÍDEO
# Criada por Geovani
# ============================================================

from .configuracao import MOTORES_VIDEO, MOTOR_PADRAO


def listar_motores():
    return MOTORES_VIDEO.copy()


def obter_motor_padrao():
    return MOTOR_PADRAO


def motor_existe(nome_motor):
    return nome_motor in MOTORES_VIDEO


def escolher_motor(nome_motor=None):
    if not nome_motor:
        return MOTOR_PADRAO
    return nome_motor if motor_existe(nome_motor) else MOTOR_PADRAO


def status_motores():
    return {
        motor: {
            "nome": motor,
            "disponivel": motor == "Automático",
        }
        for motor in MOTORES_VIDEO
    }
